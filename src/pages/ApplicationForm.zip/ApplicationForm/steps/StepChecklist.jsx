import { Card } from '../ui/index.jsx'

const ListIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M9 6h11M9 12h11M9 18h11" /><path d="M4 6h.01M4 12h.01M4 18h.01" />
  </svg>
)

// Only items the applicant can realistically gather/upload before a decision has been
// made (e.g. before acceptance) are listed here. The registration fee, an original
// health certificate and an original police clearance certificate are normally only
// requested after an offer is made, so they've been removed from this early checklist.
const ITEMS = [
  ['passportPhotos', 'Three (3) recent passport-size photos'],
  ['passportCopy', 'Passport Copy'],
  ['recommendationLetters', 'Two Letters of Recommendation'],
  ['personalStatementSubmitted', 'Personal Statement (typed and double spaced)'],
  ['transcriptsSubmitted', 'Certified or Notarized copies of transcripts & Degree of your Undergraduate studies in English'],
  ['highSchoolDiplomaSubmitted', 'Certified copies of High School Diploma in English'],
]

export default function Step1Checklist({ data, update }) {
  const cl = data.checklist

  return (
    <Card icon={<ListIcon />} title="Checklist">
      <p className="text-sm text-[#0D1B2E] mb-5">
        Note: Your application will NOT be reviewed unless all the applicable sections are completely answered and
        include all required items listed below.
      </p>
      <p className="text-sm font-semibold text-[#0D1B2E] mb-3">
        Please enclose or forward the following items along with your application
      </p>

      <div className="mb-6">
        {ITEMS.map(([key, label]) => (
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2.5 py-3 border-b border-[#0F4C81]/10 last:border-0">
            <span className="text-sm text-[#0D1B2E] font-medium pr-3">{label}</span>
          </div>
        ))}
      </div>
    </Card>
  )
}